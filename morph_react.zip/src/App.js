import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Header from './Header';
import { AuthProvider } from './AuthContext';
// import CombinedComponent from './components/CombinedComponent'; // Объединенный компонент
import Reactthreefiber from './Reactthreefiber';
import Component6 from './Component6';
import Carousel from './Carousel';
import Ques from './Ques';
import Heading from './Heading';
import Greetings from './Greetings';
import Footter from './Footter';
import Deadlines from './Deadlines';



function App() {
  return (
    <Router>
      <AuthProvider>
        <Header /> {/* Header будет отображаться на всех страницах */}
        {/* <CombinedComponent /> Объединенный компонент */}
        <Reactthreefiber /> {/* Добавляем сцену с 3D объектами */}
        <Greetings />
        <Component6 />
        <Heading />
        <Carousel />
        <Ques />
        <Deadlines />
      </AuthProvider>
      <Footter />
    </Router>
  );
}

export default App;

