import React, { useEffect, useRef } from 'react';

const Component6 = () => {
    const cardsRef = useRef([]);

    useEffect(() => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Если карточка пересекает область видимости (центр экрана), запускаем анимацию
                    entry.target.classList.remove('opacity-0', 'translate-y-4');
                    entry.target.classList.add('opacity-100', 'translate-y-0');
                } else {
                    // Сбрасываем анимацию, если карточка уходит с экрана
                    entry.target.classList.remove('opacity-100', 'translate-y-0');
                    entry.target.classList.add('opacity-0', 'translate-y-4');
                }
            });
        }, {
            threshold: 0.1, // Определяет, что элемент считается видимым, когда 50% его площади видно
            rootMargin: '0px 0px -50% 0px' // Область пересечения: запускаем анимацию, когда элемент пересекает центр экрана
        });

        cardsRef.current.forEach(card => {
            if (card) {
                observer.observe(card);
            }
        });

        return () => {
            cardsRef.current.forEach(card => {
                if (card) {
                    observer.unobserve(card);
                }
            });
        };
    }, []);

    return (
        <section className="h-auto sm:h-auto md:h-auto lg:h-auto mt-60 sm:mt-60 md:mt-28 lg:mt-36">
            <div className="container">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
                    {['разработка сайтов', 'фирменный стиль', 'интеграция маркетов', 'чат-боты'].map((title, index) => (
                        <div
                            key={index}
                            ref={(el) => (cardsRef.current[index] = el)}
                            className="card flex flex-col justify-between rounded-md h-72 md:h-96 p-4 border-2 border-white opacity-0 translate-y-4 transition-all duration-700 ease-in-out"
                        >
                            <h2 className="font-semibold text-success text-2xl 2xl:text-5xl inline-block align-text-top">
                                {title.split(' ')[0]}<br />
                                {title.split(' ')[1]}
                            </h2>
                            <p className="mt-2 text-gray-300 text-xl 2xl:text-3xl">
                                {title === 'разработка сайтов'
                                    ? 'быстрое развёртывание и оптимизация сайтов'
                                    : title === 'фирменный стиль'
                                        ? '2D/3D дизайн, айдентика, анимация'
                                        : title === 'интеграция маркетов'
                                            ? 'импорт товаров, настройка лк, автоматизация'
                                            : 'ai асситенты, чат-боты'}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Component6;
