import React, { useState } from 'react';

const Accordion = ({ title, children }) => {
  const [active, setActive] = useState(false);

  return (
    <div>
      <div className="tab__header rounded-md">
        <a
          href="#"
          className="tab__link p-4 block bg-primary h-48 no-underline font-semibold text-success text-2xl 2xl:text-5xl flex justify-between space-y-2 rounded-md"
          onClick={(e) => {
            e.preventDefault();
            setActive(!active);
          }}
        >
          {title}
          <span className="down-Arrow">{!active ? '⤵' : '⤴'}</span>
        </a>
      </div>
      {active && <div className="tab__content p-2 bg-white rounded-md mt-2">{children}</div>}
    </div>
  );
};

const Ques = () => {
  return (
    <section className="mx-auto mt-60 sm:mt-60 md:mt-28">
      <div className="container grid grid-cols-1 md:grid-cols-2 gap-2">
        <div className="flex flex-col gap-2">
          <Accordion title="планирование">
            <p className="pb-5 text-xl">
              проводим детальный анализ вашей отрасли, изучаем конкурентов и
              исследуем целевую аудиторию - это помогает сформировать четкое
              представление о вашей уникальности и определить, каким образом ваш
              сайт может привлекать и удерживать посетителей.
            </p>
            <p className="pb-5 text-xl">
            </p>
          </Accordion>

          <Accordion title="дизайн и макет">
            <p className="pb-5 text-xl">
              стремимся создать простой и удобный интерфейс пользователя (UI),
              который обеспечивает понятную навигацию и интуитивное взаимодействие с сайтом,
              в то же время также обращаем внимание на пользовательский опыт (UX), чтобы убедиться,
              что посетители сайта имеют приятное взаимодействие и легко достигают своих целей.
            </p>
            <p className="pb-5 text-xl">
            </p>
          </Accordion>
        </div>

        <div className="flex flex-col gap-2">
          <Accordion title="разработка">
            <p className="pb-5 text-xl">
              Lorem ipsum dolor sit amet, ut alii voluptaria est, ad illum inimicus deterruisset eam. His eu bonorum adipisci definiebas, no vis nostrud conclusionemque.
            </p>
            <p className="pb-5 text-xl">
              Ut vel percipit facilisi, sea partem veritus mandamus eu, at debet deleniti eos. Iudico suscipit mel ut. Per ad habeo sadipscing concludaturque.
            </p>
          </Accordion>

          <Accordion title="тесты и поддержка">
            <p className="pb-5 text-xl">
              Lorem ipsum dolor sit amet, ut alii voluptaria est, ad illum inimicus deterruisset eam. His eu bonorum adipisci definiebas, no vis nostrud conclusionemque.
            </p>
            <p className="pb-5 text-xl">
              Ut vel percipit facilisi, sea partem veritus mandamus eu, at debet deleniti eos. Iudico suscipit mel ut. Per ad habeo sadipscing concludaturque.
            </p>
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default Ques;