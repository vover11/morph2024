import React, { useEffect, useRef } from 'react';


const Deadlines = () => {

    return (
        <section className='mt-60 sm:mt-60 md:mt-28 lg:mt-36'>
            <div className="h-192 flex flex-col w-full gap-2">
                {/* Контейнер 1 */}
                <div className="flex-1 border-2 border-success rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-none">
                    <div class="p-2">

                        <h2 class=" font-semibold text-success text-2xl 2xl:text-5xl">
                            адаптивная вёрстка
                        </h2>




                        <p class="underline text-center text-white font-semibold text-4xl 2xl:text-5xl" >
                            01
                        </p>


                            <div class="text-center h-full flex  justify-end">
                                <p class="text-white text-right 2xl:text-4xl">14 дней</p>
                            </div>

                    </div>
                </div>
                {/* Контейнер 2 */}
                <div className="flex-1 border-2 border-success rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-none p-6">
                    Контейнер 2
                </div>
                {/* Контейнер 3 */}
                <div className="flex-1 border-2 border-success rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-none p-6">
                    Контейнер 3
                </div>
                {/* Контейнер 4 */}
                <div className="flex-1 border-2 border-success rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-none p-6">
                    Контейнер 4
                </div>
                {/* Контейнер 5 */}
                <div className="flex-1 border-2 border-success rounded-tl-none rounded-tr-xl rounded-bl-xl rounded-br-none p-6">
                    Контейнер 5
                </div>
            </div>
        </section>
    );
};

export default Deadlines;